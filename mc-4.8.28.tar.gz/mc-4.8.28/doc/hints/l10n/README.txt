ATTENTION! Don't edit hint-files in this directory!

Remember that all these files is a TARGET for files originally placed on Transifex:
https://www.transifex.com/projects/p/mc/resource/mc_hint/
